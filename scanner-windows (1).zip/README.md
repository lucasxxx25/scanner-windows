
# Scanner de Serviços do Windows

Este repositório contém um analisador de serviços do Windows com interface gráfica, que utiliza a API do VirusTotal para identificar executáveis potencialmente maliciosos em execução no sistema.

## Arquivos incluídos

- `scanner_gui.py` — Interface gráfica do scanner com análise detalhada de serviços.
- `setup_scanner.py` — Script que instala os requisitos e baixa o scanner.
- `iniciar_setup.bat` — Script de inicialização para sistemas Windows (executar como administrador).

## Como usar

1. **Clone ou baixe o repositório:**
   ```bash
   git clone https://github.com/SEU_USUARIO/scanner-windows.git
   cd scanner-windows
   ```

2. **Execute o instalador (Windows):**
   Clique com o botão direito sobre `iniciar_setup.bat` e selecione "Executar como administrador".

3. **Abra a interface do scanner:**
   Ao final da instalação, o arquivo `scanner_gui.py` estará pronto para ser executado:
   ```bash
   python scanner_gui.py
   ```

## Requisitos

- Python 3.7+
- Conexão com a internet
- Sistema operacional Windows
- API Key do VirusTotal (já incluída no exemplo)

## Observações de segurança

A API Key usada neste repositório é pública para fins de demonstração. Para uso real, registre-se em https://www.virustotal.com e use sua própria chave.
