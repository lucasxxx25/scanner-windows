
import psutil
import hashlib
import os
import pefile
import requests
import ctypes
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, scrolledtext

VT_API_KEY = "e1ff77f76aaacfbfa34e519e267938d2c97a28a5fea47444126c31eac09431cb"
VT_URL = "https://www.virustotal.com/api/v3/files"

HASH_CACHE_FILE = "hash_cache.txt"

def calculate_sha256(file_path):
    try:
        with open(file_path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception:
        return None

def load_cached_hashes():
    if not os.path.exists(HASH_CACHE_FILE):
        return set()
    with open(HASH_CACHE_FILE, "r") as f:
        return set(line.strip() for line in f.readlines())

def save_hash_to_cache(file_hash):
    with open(HASH_CACHE_FILE, "a") as f:
        f.write(file_hash + "\n")

def check_virustotal(file_hash):
    headers = {"x-apikey": VT_API_KEY}
    response = requests.get(f"{VT_URL}/{file_hash}", headers=headers)
    if response.status_code == 200:
        json_data = response.json()
        malicious = json_data['data']['attributes']['last_analysis_stats']['malicious']
        return malicious > 0
    return False

def is_legit_executable(file_path):
    try:
        pe = pefile.PE(file_path)
        return True
    except:
        return False

def analyze_services():
    cached_hashes = load_cached_hashes()
    suspicious = []

    for proc in psutil.process_iter(['pid', 'name', 'exe', 'username', 'create_time']):
        try:
            exe_path = proc.info['exe']
            reasons = []

            if exe_path and Path(exe_path).exists():
                file_hash = calculate_sha256(exe_path)
                if not file_hash or file_hash in cached_hashes:
                    continue

                if not is_legit_executable(exe_path):
                    reasons.append("Arquivo PE inválido")

                if check_virustotal(file_hash):
                    reasons.append("Detectado como malicioso")

                if not exe_path.lower().startswith(("c:\windows", "c:\program files")):
                    reasons.append("Local incomum do executável")

                if reasons:
                    suspicious.append({
                        "nome": proc.info['name'],
                        "caminho": exe_path,
                        "usuario": proc.info.get('username', 'Desconhecido'),
                        "motivos": ", ".join(reasons)
                    })

                save_hash_to_cache(file_hash)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    return suspicious

def executar_analise(output_box):
    if not ctypes.windll.shell32.IsUserAnAdmin():
        messagebox.showerror("Permissão necessária", "Execute o programa como administrador.")
        return

    output_box.delete("1.0", tk.END)
    output_box.insert(tk.END, "Analisando serviços em execução...\n\n")

    result = analyze_services()
    if not result:
        output_box.insert(tk.END, "Nenhuma ameaça detectada.\n")
    else:
        for proc in result:
            output_box.insert(tk.END, f"Processo: {proc['nome']}\n")
            output_box.insert(tk.END, f"Caminho: {proc['caminho']}\n")
            output_box.insert(tk.END, f"Usuário: {proc['usuario']}\n")
            output_box.insert(tk.END, f"Motivo(s): {proc['motivos']}\n\n")

def criar_interface():
    janela = tk.Tk()
    janela.title("Analisador de Serviços do Windows")
    janela.geometry("700x500")

    label = tk.Label(janela, text="Clique no botão para iniciar a análise de processos suspeitos")
    label.pack(pady=10)

    botao = tk.Button(janela, text="Iniciar Análise", command=lambda: executar_analise(output_box))
    botao.pack(pady=5)

    output_box = scrolledtext.ScrolledText(janela, wrap=tk.WORD, width=80, height=25)
    output_box.pack(padx=10, pady=10)

    janela.mainloop()

if __name__ == "__main__":
    criar_interface()
